//#define DEBUG_SERIALSETUP
//#define DEBUG
//#define SIMULATION

#include <SPI.h>
#include <Ethernet.h>

/* some other way of smoothing...
#ifndef SIMULATION
    #include "Filter.h"
#endif
*/

#define ON 0
#define OFF 1
#define RelayCWRightP6 6
#define RelayCCWLeftP7 7
#define PotiPin 0
#define STATUS_TURNING_CCWLEFT0 0
#define STATUS_TURNING_CWRIGHT1 1
#define STATUS_TURNING_NOT -1

byte mac[] = {
    0xDE,
    0xAD,
    0xBE,
    0xEF,
    0xFE,
    0xED};
IPAddress ip(192, 168, 1, 120);
EthernetServer server(80);
String readString = ""; // string for fetching data from address
String cmd = "";

/* other way of smoothing
#ifndef SIMULATION
// Create a new exponential filter with a weight of 10 and initial value of 0. 
ExponentialFilter<long> ADCFilter(40, 0);
#endif
*/

int leftLimit = 200;
int rightLimit = 800;
float middle = 0;
float calculationFactorDeg = 0;

float currentPostitionDeg = 180;
float currentPositionValue = 200;
int goToDeg = 180;
int goToValue = 200;

bool isTurningActionCalled = false;
bool isStopped = true;
int status = STATUS_TURNING_NOT;

#ifdef DEBUG_SERIALSETUP
void setupSerial(){
    Serial.begin(115200);
    while (!Serial)
    {
        ; // wait for serial port to connect. Needed for native USB port only
    }
}
#endif

float GetValueByDegSouth(int deg)
{
    if (deg > 180 && deg < 360)
        return ((deg - 180) * calculationFactorDeg) + leftLimit;
    if (deg < 180 && deg > 0)
        return rightLimit - ((180 - deg) * calculationFactorDeg);

    if (deg == 180 && currentPostitionDeg < 360 && currentPostitionDeg > 180)
        return leftLimit;
    if (deg == 180 && currentPostitionDeg < 180)
        return rightLimit;

    if (deg == 0 || deg == 360)
        return middle;

    if (deg == 180 && currentPostitionDeg == 180)
        return currentPositionValue;

    return -1;
}

float GetDegByValueSouth(int value)
{
    if (value > leftLimit && value < middle)
        return ((value - leftLimit) / calculationFactorDeg) + 180.00;
    if (value > middle && value < rightLimit)
        return 180.00 - ((rightLimit - value) / calculationFactorDeg);

    if (value == middle)
        return 0;

    if (value == currentPositionValue)
        return currentPostitionDeg;

    if (value == leftLimit || value == rightLimit)
        return 180;

    return -1;
}

#ifndef SIMULATION
void readPotiAndSetCurrentDegCurrentValue(){

    unsigned long  sum = 0;

    for(int y = 0; y<10; y++)
    {
        int RawValue = analogRead(PotiPin);
        sum += RawValue;
        delay(2);
    }
    currentPositionValue = (sum / 10);
    currentPostitionDeg = GetDegByValueSouth(currentPositionValue);
#ifdef DEBUG
    Serial.print(" finalsum ");
    Serial.println(currentPositionValue);
#endif
}
#endif

/* Some other posibilities to smoothen ADC readings
long oversample(int pin, int pbit) {
long summe=0;
  for(int i=0; i < pow(4.0,pbit); i++) {
    summe += analogRead(pin);
  }
  return summe >> pbit;
}

void readPotiAndSetCurrentDegCurrentValue(){

    int RawValue = analogRead(0);
    ADCFilter.Filter(RawValue);
    currentPositionValue = ADCFilter.Current();
    currentPostitionDeg = GetDegByValueSouth(currentPositionValue)
}


void readPotiAndSetCurrentDegCurrentValue__(){

    float sum = 0;

    for(int y = 0; y<10; y++)
    {
        int RawValue = analogRead(0);
        sum += RawValue;
    } 
    currentPositionValue = sum / 10;
    currentPostitionDeg = GetDegByValueSouth(currentPositionValue)
}

void readPotiAndSetCurrentDegCurrentValue_(){
    float RawValue = oversample(analogRead(0),4) << 4;
    ADCFilter.Filter(RawValue);
    currentPositionValue = ADCFilter.Current();
    currentPostitionDeg = GetDegByValueSouth(currentPositionValue)
}
*/


#ifdef DEBUG
void DebugPrintGlobals()
{
    Serial.print("middle:");
    Serial.println(middle);

    Serial.print("goToDeg:");
    Serial.println(goToDeg);

    Serial.print("goToValue:");
    Serial.println(goToValue);

    Serial.print("currentPostitionDeg:");
    Serial.println(currentPostitionDeg);

    Serial.print("calculationFactorDeg:");
    Serial.println(calculationFactorDeg, 16);

    delay(1000);
}
#endif



#ifndef SIMULATION
void setRelayCWRightP6(byte state){
    digitalWrite(RelayCWRightP6, state);
}

void setRelayCCWLeftP7(byte state){
    digitalWrite(RelayCCWLeftP7, state);
}
#endif

void stop()
{
    // ToDo all relay off
    // wait 5s?
    // read poti
#ifndef SIMULATION
    readPotiAndSetCurrentDegCurrentValue();
    setRelayCWRightP6(OFF);
    setRelayCCWLeftP7(OFF);
#endif

    status = STATUS_TURNING_NOT;
    isStopped = true;
    goToDeg = currentPostitionDeg;
    goToValue = currentPositionValue;
    isTurningActionCalled = false;
#ifdef DEBUG
    Serial.println("ich habe gestoppt");
    DebugPrintGlobals();
    delay(2000);
#endif
}

int getTurningDirectionByValue(int valueToTurnTo)
{
    if (valueToTurnTo < currentPositionValue)
        return 0; // ccw
    else
        return 1; // cw
}

String getValue(String data, char separator, int index)
{
    int found = 0;
    int strIndex[] = {
        0,
        -1};
    int maxIndex = data.length() - 1;

    for (int i = 0; i <= maxIndex && found <= index; i++)
    {
        if (data.charAt(i) == separator || i == maxIndex)
        {
            found++;
            strIndex[0] = strIndex[1] + 1;
            strIndex[1] = (i == maxIndex) ? i + 1 : i;
        }
    }
    return found > index ? data.substring(strIndex[0], strIndex[1]) : "";
}

void WebServer()
{
    EthernetClient client = server.available();
    if (client)
    {
#ifdef DEBUG
        Serial.println("new client");
        // an http request ends with a blank line
#endif
        boolean currentLineIsBlank = true;
        while (client.connected())
        {
            if (client.available())
            {
                char c = client.read();
                int lenStr = readString.length();

                if (lenStr < 11)
                {
                    readString.concat(c);
                }

                if (lenStr == 11 || (c == '\n' && currentLineIsBlank))
                {
#ifdef DEBUG
                    Serial.println(readString);
#endif
                    String cmd = getValue(readString, '/', 1);

                    if (cmd == "Stop")
                    {
                        stop();
                        isTurningActionCalled = false;
                        isStopped = true;
                    }

                    if (cmd == "Go")
                    {
                        String cmd_deg = getValue(readString, '/', 2);
                        goToDeg = cmd_deg.toInt();
                        isTurningActionCalled = true;
#ifdef DEBUG
                        Serial.print("Go command rotation to ");
                        Serial.println(goToDeg);
#endif
                    }
                    else
                   {
                       // ToDo Read poti !!
#ifndef SIMULATION
                        readPotiAndSetCurrentDegCurrentValue();
#endif                        
                        isTurningActionCalled = false;
                   } 
#ifdef DEBUG
                    Serial.println(cmd);
                    Serial.println(goToDeg);
                    DebugPrintGlobals();
#endif
                    client.println("HTTP/1.1 200 OK");
                    client.println("Content-Type: application/json");
                    client.println("Access-Control-Allow-Origin: *");
                    client.println("Accept: application/json");
                    ;
                    client.println("Connection: close"); // the connection will be closed after completion of the response
                    client.println();
                    client.print("{\"p\": ");
                    client.print(currentPostitionDeg);
                    client.print(", ");
                    client.print("\"v\": ");
                    client.print(currentPositionValue);
                    client.print(", \"s\": ");
                    client.print(status);
                    client.print("}");
                    break;
                }
                if (c == '\n')
                {
                    currentLineIsBlank = true;
                }
                else if (c != '\r')
                {
                    currentLineIsBlank = false;
                }
            }
        }
        delay(2);
        client.stop();
        readString = "";
        cmd = "";
#ifdef DEBUG
        Serial.println("client disconnected");
#endif
    }
}

void turnCW()
{
#ifdef DEBUG
    Serial.println("Ich drehe mich im Uhrzeigersinn");
#endif
    while (!isStopped && currentPositionValue < goToValue)
    {
#ifndef SIMULATION 
        // turn on relays
        setRelayCWRightP6(ON);
        readPotiAndSetCurrentDegCurrentValue();
        // read poti
#else
        currentPositionValue += 2;
        currentPostitionDeg = GetDegByValueSouth(currentPositionValue);

#endif
        status = STATUS_TURNING_CWRIGHT1;
#ifdef DEBUG        
        Serial.print("Bin gerade ");
        Serial.print(currentPositionValue);
        Serial.print(" Bin Deg ");
#endif
        if (currentPostitionDeg == -1)
            currentPostitionDeg = 180;
#ifdef DEBUG
        Serial.println(currentPostitionDeg);
#endif
        WebServer();
#ifdef SIMULATION
        delay(300);
#endif
    }
    stop();
}

void turnCCW()
{
#ifdef DEBUG
    Serial.println("Ich drehe mich gegen Uhrzeigersinn");
#endif
    while (!isStopped && currentPositionValue > goToValue)
    {
        // turn on relays
        // read poti
#ifndef SIMULATION 
        // turn on relays
        setRelayCCWLeftP7(ON);
        readPotiAndSetCurrentDegCurrentValue();
        // read poti
#else
        currentPositionValue -= 2;
        currentPostitionDeg = GetDegByValueSouth(currentPositionValue);
#endif
        status = STATUS_TURNING_CCWLEFT0;
#ifdef DEBUG
        Serial.print("Bin gerade ");
        Serial.print(currentPositionValue);
        Serial.print(" Bin Deg ");
#endif
        if (currentPostitionDeg == -1)
            currentPostitionDeg = 180;
#ifdef DEBUG            
        Serial.println(currentPostitionDeg);
#endif
        WebServer();
#ifdef SIMULATION
        delay(300);
#endif
    }
    stop();
}

void setup()
{
#ifdef DEBUG_SERIALSETUP
    setupSerial();
#endif

    Ethernet.begin(mac, ip);
    server.begin();
#ifdef DEBUG
    Serial.print("server is at ");
    Serial.println(Ethernet.localIP());
#endif


    middle = ((rightLimit -leftLimit) / 2)+leftLimit;
    calculationFactorDeg = ((rightLimit-leftLimit) / 360.00)+0.000000066667;
    

#ifndef SIMULATION
    pinMode(RelayCWRightP6, OUTPUT);   
    pinMode(RelayCCWLeftP7, OUTPUT);   

    digitalWrite(RelayCWRightP6, OFF);
    digitalWrite(RelayCCWLeftP7, OFF);
    readPotiAndSetCurrentDegCurrentValue();
#endif

/* other type of smoothing
#ifndef SIMULATION
    int counter = 0;
    while (counter < 30)
    {
        ADCFilter.SetCurrent(ADCFilter.Current());
        readPotiAndSetCurrentDegCurrentValue();
        Serial.println(currentPositionValue);
        counter++;
        delay(5);
    }
#endif
*/
}

void loop()
{

    if (isTurningActionCalled == true && currentPostitionDeg != goToDeg)
    {
#ifdef DEBUG
        Serial.print("Ich muss drehen!");
#endif
        goToValue = GetValueByDegSouth(goToDeg);
        int turningDirection = getTurningDirectionByValue(goToValue);
        isStopped = false;
        if (turningDirection == 0)
            turnCCW();
        else
            turnCW();
    }
    else
    {
#ifndef SIMULATION
        readPotiAndSetCurrentDegCurrentValue();
#endif
        WebServer();
    }
}