$(document).ready(function(){

    var deg = 0;

    function rotator( $domNode ) {

        // layers
        var $currentPosition = $('.js-currentPosition', $domNode).first();
        var $targetPosition  = $('.js-targetPosition', $domNode).first();

        // info values
        var $current         = $('.js-current', $domNode).first();
        var $target          = $('.js-target', $domNode).first();

        // buttons
        var $set             = $('.js-set', $domNode).first();
        var $rand            = $('.js-rand', $domNode).first();

    }

    rotator( $('.js-first') );

    function rotate($element, degree) {
        $element.css({
            '-webkit-transform': 'rotate(' + degree + 'deg)',
               '-moz-transform': 'rotate(' + degree + 'deg)',
                '-ms-transform': 'rotate(' + degree + 'deg)',
                 '-o-transform': 'rotate(' + degree + 'deg)',
                    'transform': 'rotate(' + degree + 'deg)'
        });
    }
    
    document.onmousemove = handleMouseMove;
    function handleMouseMove(event) {
        var eventDoc, doc, body;

        event = event || window.event;

        if (event.pageX == null && event.clientX != null) {
            eventDoc = (event.target && event.target.ownerDocument) || document;
            doc = eventDoc.documentElement;
            body = eventDoc.body;

            event.pageX = event.clientX +
              (doc && doc.scrollLeft || body && body.scrollLeft || 0) -
              (doc && doc.clientLeft || body && body.clientLeft || 0);
            event.pageY = event.clientY +
              (doc && doc.scrollTop  || body && body.scrollTop  || 0) -
              (doc && doc.clientTop  || body && body.clientTop  || 0 );
        }

        var diffx = event.pageX-mapx;
        var diffy = mapy-event.pageY;

        $('#mx').html(event.pageX-mapx);
        $('#my').html(mapy-event.pageY);

        var quad = 0;
        var rad = (Math.PI/180);

        if(diffx > 0 && diffy > 0)
            quad = 1;
        
        if(diffx < 0 && diffy > 0)
            quad = 2;

        if(diffx < 0 && diffy < 0)
            quad = 3;

        if(diffx > 0 && diffy < 0)
            quad = 4;

        if(quad== 1 || quad == 4)
            erg = Math.round(90-(Math.atan(diffy/diffx)/rad));
        else
            erg = Math.round(270-(Math.atan(diffy/diffx)/rad));

        $('#w').html(erg);
        $('#q').html(quad);

    }

    document.onclick = handleOnClick;
    function handleOnClick(event) {
        rotate($('.rotator__target'), erg);
    }

    function centerImages() {
        var div = $('.rotator__background');
        var divCoords = { 
            x : div.width() * 0.5, 
            y : div.height() * 0.5
        };
     
        mapx = divCoords.x;
        mapy = divCoords.y;
    
        $('#ix').html(mapx);
        $('#iy').html(mapy);
    
    }
    
    centerImages();
});



var mapx = 0;
var mapy = 0;
var erg = 0;
